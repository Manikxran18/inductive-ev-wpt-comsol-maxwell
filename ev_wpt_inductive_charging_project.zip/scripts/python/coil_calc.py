#!/usr/bin/env python3

"""
Coil calculator: Wheeler spiral inductance + skin depth.
"""
import argparse, math

MU0 = 4*math.pi*1e-7

def wheeler_spiral_L_uH(N, r_in_mm, r_out_mm, width_mm):
    r_in = r_in_mm/1000
    r_out = r_out_mm/1000
    r_avg = 0.5*(r_in + r_out)
    w = width_mm/1000
    L = (MU0 * (N**2) * (r_avg**2)) / (8*r_avg + 11*w)  # Henries
    return L*1e6

def skin_depth_mm(freq_khz, rho=1.68e-8, mu_r=1.0):
    w = 2*math.pi*freq_khz*1e3
    mu = MU0*mu_r
    delta = math.sqrt(2*rho/(w*mu))
    return delta*1000

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--N", type=int, required=True)
    p.add_argument("--r_in_mm", type=float, required=True)
    p.add_argument("--r_out_mm", type=float, required=True)
    p.add_argument("--width_mm", type=float, required=True)
    p.add_argument("--freq_khz", type=float, default=85)
    args = p.parse_args()
    L_uH = wheeler_spiral_L_uH(args.N, args.r_in_mm, args.r_out_mm, args.width_mm)
    delta_mm = skin_depth_mm(args.freq_khz)
    print(f"Spiral L ≈ {L_uH:.2f} µH")
    print(f"Skin depth at {args.freq_khz} kHz ≈ {delta_mm:.3f} mm")

if __name__ == "__main__":
    main()
