#!/usr/bin/env python3

"""
Rudimentary LCC-S sizing helper using first-order targets.

Assumptions:
- Operating freq f (Hz)
- Target power P (W) into DC link Vbat_nom (V)
- Initial guess for L1, L2, k; computes M. Then derives ballpark Cp, Lp(series), Lp(parallel), Cs.
**You should refine with circuit/FEM co-simulation.**
"""
import argparse, math

def lcc_s_size(power_kw=3.3, vbat_nom=360, freq_khz=85, L1_uH=200, L2_uH=200, k=0.18, Q_target=4.0):
    f = freq_khz*1e3
    w = 2*math.pi*f
    P = power_kw*1000
    L1 = L1_uH*1e-6
    L2 = L2_uH*1e-6
    M = k*math.sqrt(L1*L2)

    # Crude gain to target primary reactive currents; pick Cp for series resonance with Lp_series
    Z_target = (vbat_nom**2)/P  # ohms seen by secondary rectifier approx
    # Choose an effective load reflected to primary: R_ref ≈ (w*M)^2 / Z_target
    R_ref = (w*M)**2 / Z_target

    # Pick Lp_series such that X_L ≈ Q_target * R_ref
    Lp_series = (Q_target * R_ref) / w
    Cp = 1/(w**2 * Lp_series)

    # Parallel branch to shape input impedance near resonance (ballpark: 1.5x)
    Lp_parallel = 1.5 * Lp_series

    # Secondary series capacitor to resonate L2 (approx)
    Cs = 1/(w**2 * L2)

    return {
        "M_H": M,
        "R_ref_ohm": R_ref,
        "Lp_series_H": Lp_series,
        "Cp_F": Cp,
        "Lp_parallel_H": Lp_parallel,
        "Cs_F": Cs
    }

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--power_kw", type=float, default=3.3)
    p.add_argument("--vbat_nom", type=float, default=360)
    p.add_argument("--freq_khz", type=float, default=85)
    p.add_argument("--L1_uH", type=float, default=200)
    p.add_argument("--L2_uH", type=float, default=200)
    p.add_argument("--k", type=float, default=0.18)
    p.add_argument("--Q_target", type=float, default=4.0)
    args = p.parse_args()

    out = lcc_s_size(args.power_kw, args.vbat_nom, args.freq_khz,
                     args.L1_uH, args.L2_uH, args.k, args.Q_target)

    for k_, v in out.items():
        if v < 1e-6:
            print(f"{k_}: {v:.6e}")
        else:
            print(f"{k_}: {v:.6g}")

if __name__ == "__main__":
    main()
