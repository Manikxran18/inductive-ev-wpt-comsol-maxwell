#!/usr/bin/env python3

"""
Analyze WPT sweep data and create plots/tables.

Usage:
    python scripts/python/analyze_efficiency.py --csv data/sweeps/sample_sweep.csv
"""
import argparse, pandas as pd, matplotlib.pyplot as plt

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True, help="Path to sweep CSV")
    args = p.parse_args()

    df = pd.read_csv(args.csv)
    print("Rows:", len(df))
    print(df.head())

    # Plot PTE vs gap for each misalignment at ~85 kHz (nearest)
    target_f = 85
    df_f = df.iloc[(df["freq_khz"]-target_f).abs().argsort()].groupby(["gap_mm","misalign_mm"]).head(1)

    for mis, g in df_f.groupby("misalign_mm"):
        g_sorted = g.sort_values("gap_mm")
        plt.figure()
        plt.plot(g_sorted["gap_mm"], g_sorted["pte"], marker="o")
        plt.title(f"PTE vs Gap @ ~{target_f} kHz (misalign={mis} mm)")
        plt.xlabel("Gap (mm)")
        plt.ylabel("PTE (0-1)")
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(f"data/plots/pte_vs_gap_mis{mis}.png", dpi=180)

    # Pivot table of average losses by gap and misalignment
    pt = df.groupby(["gap_mm","misalign_mm"])["loss_W"].mean().unstack()
    print("\nAverage Loss (W) by Gap x Misalignment")
    print(pt.round(1))
    pt.to_csv("data/plots/avg_loss_table.csv")

    # Scatter PTE vs coupling
    plt.figure()
    plt.scatter(df["coupling_k"], df["pte"])
    plt.title("PTE vs Coupling k")
    plt.xlabel("Coupling k")
    plt.ylabel("PTE (0-1)")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("data/plots/pte_vs_k.png", dpi=180)

if __name__ == "__main__":
    main()
