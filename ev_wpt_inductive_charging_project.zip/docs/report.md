# Inductive WPT for EVs — Technical Report

## 1. System Requirements
- Nominal power: 3.3 kW (easily adapted 1–7 kW)
- DC link: 360–420 V (vehicle), AC inverter drives primary coil at ~85 kHz
- Target PTE: ≥ 90% at 150 mm gap, lateral misalignment ±100 mm

## 2. Coil & Magnetic Design
### 2.1 Geometry
- Primary pad: circular spiral or double‑D (DD) with ferrite tiles underneath
- Secondary: circular spiral or DD to match primary
- Conductors: Litz wire sized for 85 kHz RMS current and temperature rise
- Ferrite: MnZn tiles, ensure flux density < 0.2–0.3 T at hotspots (iterate in FEM)

### 2.2 First‑Order Inductance (Wheeler approximations)
- Circular spiral inductance (µH):  
  L ≈ (μ0 * N^2 * r_avg^2) / (8 * r_avg + 11 * w)  
  where N=turns, r_avg=average radius, w=trace width

### 2.3 Coupling
- M = k * sqrt(L1 * L2). Target k ~ 0.1–0.25 at nominal gap for compact pads.
- Include ferrite and aluminum shields as separate regions; track eddy losses.

## 3. Compensation Network
- Start with **LCC‑S** (primary LCC, secondary series): good ZVS range and tolerance to k variation.
- Tune for unity power factor seen by inverter near nominal load.
- Export component stresses (Vrms, Irms, Q) from circuit co‑simulation.

## 4. FEM Setup (COMSOL/Maxwell)
- Physics: **frequency‑domain eddy currents** at 60–90 kHz.
- Excite primary with current source (or voltage with series R), observe secondary induced voltage.
- Mesh: refined at conductors and ferrite edges. Use **multi‑turn conductor** or **homogenized Litz** models.
- Parametric sweep: gap=[100,150,200] mm; lateral dx=[0,50,100] mm; freq=[75,85,95] kHz.

## 5. Data to Export
- L1, L2, M, R1_ac, R2_ac, copper/core losses, field snapshots in planes, induced Vsec.
- Compute PTE using: η = Pload / Pin. For two‑port: use Z‑parameters or circuit model with LCC.

## 6. Thermal (Back‑of‑Envelope)
- T_rise ≈ P_loss / (h * A). Use h=5–10 W/m²K natural convection as a sanity check.
- Validate hotspots with IR camera or coupled thermal if available.

## 7. EMF/EMC
- Plot |H| and |B| on ground/side planes at rated power; flag exceedances for design tweaks.

## 8. Results & Discussion
- Include PTE vs gap/misalignment, loss pie chart, field plots, component stresses.
- Sensitivity to k, detuning ±5%, and load variation.
