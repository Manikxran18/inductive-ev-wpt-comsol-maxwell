# Coil & Compensation Design Notes

## Targets
- Power: 3.3 kW @ 85 kHz
- DC bus: 360–420 V
- Gap: 100–200 mm
- Misalignment tolerance: ±100 mm lateral

## Spiral Inductance (Wheeler)
- L ≈ (μ0 * N^2 * r_avg^2) / (8*r_avg + 11*w)
- r_avg = (r_out + r_in)/2 ; w = trace/turn width or wire bundle effective width
- Check AC resistance with skin depth δ = sqrt(2ρ/(ωμ)). Use Litz to reduce Rac.

## Compensation
- LCC‑S: Cp, Lp(series), Lp(parallel), Cs(secondary series). Tune for ZVS and target gain.
