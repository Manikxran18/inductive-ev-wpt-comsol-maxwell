# Wireless Charging System Design for EVs – Inductive WPT (COMSOL/Maxwell)

**Objective:** Model an **inductive wireless power transfer (WPT)** system for EVs using **COMSOL Multiphysics** or **ANSYS Maxwell**, design primary/secondary coils, and analyze **power transfer efficiency (PTE)** and loss breakdown. This repo includes simulation setup guides, parameter sweeps, and Python scripts for analysis and figures.

> 🔬 Tools: COMSOL Multiphysics / ANSYS Maxwell (3D Eddy Current) · Python · Matplotlib  
> 📅 Last updated: 2025-08-16

## Contents
- `simulation/` – setup notes and parameter templates for COMSOL & Maxwell
- `design/` – coil and compensation design notes + formulas
- `data/` – example sweep CSVs (gap, misalignment, frequency)
- `scripts/python/` – analysis/plotting & first‑order design calculators
- `docs/` – report-style write‑up with figures you can export
- `LICENSE` – MIT

## Quick Start
1. Open `docs/report.md` to see the workflow and deliverables.
2. Use `design/coil_design_notes.md` to define target specs.
3. Build a parametric model in **COMSOL** or **Maxwell** following `simulation/*/SETUP.md`.
4. Export sweep results as CSV into `data/sweeps/`.
5. Run:
   ```bash
   python scripts/python/analyze_efficiency.py --csv data/sweeps/sample_sweep.csv
   python scripts/python/compensation_sizing.py --power_kw 3.3 --vbat_nom 360 --freq_khz 85
   ```
6. Paste generated plots/tables into `docs/report.md` and commit.

## Highlight Deliverables
- **Coil set** (primary pad + vehicle receiver) with geometry, turns, wire/Litz selection.
- **Coupling (k)**, **self/mutual inductance (L1, L2, M)**, **resistance (AC/DC)**, **PTE vs gap/misalignment**.
- **Compensation network** (e.g., LCC-S or Series-Series) with component values and sensitivity.
- **Loss breakdown**: copper, core, proximity/skin, inverter/converter, ferrite/eddy, dielectric.
- **Thermal estimate** based on copper/core losses and simple convection assumptions.
- **EMF compliance snapshot** (field on ground plane and side planes vs operating point).

## Notes
- You’ll need your own COMSOL/Maxwell license. This repo ships **templates and scripts**, not binary models.
- If you don’t have access, you can still use the Python calculators and replace FEM data with your own measurements.
