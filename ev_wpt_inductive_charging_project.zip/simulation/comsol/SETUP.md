# COMSOL Setup (AC/DC Module)

1. **Geometry**: Build primary and secondary coils (use 'Multi‑Turn Coil' feature). Add ferrite tiles and aluminum shield.
2. **Materials**: Copper (with frequency‑dependent σ), MnZn ferrite (μr(f), tanδ), Aluminum for shield.
3. **Physics**: Magnetic Fields (mf) – Frequency Domain at 85 kHz (parametric 75–95 kHz).
4. **Excitation**: Current excitation on primary (specify turns & RMS current). Secondary left open or connected to external circuit via 'Electrical Circuit' interface.
5. **Meshing**: Boundary layer near conductors; refine at ferrite edges.
6. **Studies**: Parametric sweeps for gap and misalignment.
7. **Outputs**: L1, L2, M (via Energy or Integral definitions), Rac, copper/core losses, field plots.
8. **Export**: CSV tables into `data/sweeps/`.
