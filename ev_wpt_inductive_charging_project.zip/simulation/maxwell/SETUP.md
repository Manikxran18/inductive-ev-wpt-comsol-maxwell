# ANSYS Maxwell 3D Setup (Eddy Current)

1. **Project**: Maxwell 3D → Eddy Current (Frequency Domain).
2. **Geometry**: Draw coils as spirals or import from CAD; define 'Coil' with turns. Add ferrite and shields.
3. **Excitation**: Current source on primary coil. Secondary can be 'winding' to extract L/M or connected via circuit in Simplorer/Twin Builder.
4. **Materials**: Use frequency‑dependent properties (copper, ferrite, aluminum).
5. **Mesh**: Local mesh ops on conductors and ferrite edges.
6. **Optimetrics**: Set sweeps for gap, misalignment, frequency.
7. **Reports**: Inductance matrix, losses, field plots; export to CSV in `data/sweeps/`.
